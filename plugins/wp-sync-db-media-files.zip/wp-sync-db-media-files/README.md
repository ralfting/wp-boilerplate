# WP Sync DB Media Files
An addon for [WP Sync DB](https://github.com/wp-sync-db/wp-sync-db) that lets you sync media libraries between WordPress installations.

<p align="center"><a><img src="https://raw.github.com/slang800/psychic-ninja/master/wp-sync-db-media-files.png"/></a></p>
