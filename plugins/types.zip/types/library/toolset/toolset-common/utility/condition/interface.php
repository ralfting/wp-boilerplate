<?php

interface Toolset_Condition_Interface {
	/**
	 * @return bool
	 */
	public function is_met();
}