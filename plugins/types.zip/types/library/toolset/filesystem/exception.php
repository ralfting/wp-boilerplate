<?php


class Toolset_Filesystem_Exception extends Exception {

}